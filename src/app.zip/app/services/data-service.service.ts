import { Injectable } from '@angular/core';

@Injectable()
export class DataServiceService {
  private users: User[] = new Array();
  constructor() {
    this.dataSeed();
  }

  dataSeed(): void {
    const user: User = {
      username: 'admin',
      email: 'admin@example.com',
      password: 'admin123',
      lastName: 'Admin',
      firstName: 'admin',
      mobile: '0293837847'
    };
    this.users[0] = user;
  }

  getUsers(): User[] {
    return this.users;
  }

  setUser(user: User): void {
     this.users.push(user);
  }

}


export interface User {
  username: string;
  password: string;
  email: string;
  firstName?: string;
  lastName?: string;
  mobile?: string;
}
